import { useMemo, useState } from "react";

type IconProps = {
  name:
    | "arrow"
    | "bus"
    | "calendar"
    | "card"
    | "check"
    | "chevron"
    | "clock"
    | "map"
    | "minus"
    | "plus"
    | "phone"
    | "seat"
    | "swap"
    | "user";
  size?: number;
};

function Icon({ name, size = 20 }: IconProps) {
  const paths = {
    arrow: <path d="M5 12h14m-5-5 5 5-5 5" />,
    bus: (
      <>
        <rect x="5" y="3" width="14" height="16" rx="3" />
        <path d="M5 11h14M8 7h8M7 19v2m10-2v2" />
        <circle cx="8" cy="15" r="1" fill="currentColor" />
        <circle cx="16" cy="15" r="1" fill="currentColor" />
      </>
    ),
    calendar: (
      <>
        <rect x="3" y="5" width="18" height="16" rx="3" />
        <path d="M8 3v4m8-4v4M3 10h18" />
      </>
    ),
    card: (
      <>
        <rect x="3" y="5" width="18" height="14" rx="2" />
        <path d="M3 10h18M7 15h3" />
      </>
    ),
    check: <path d="m5 12 4 4L19 6" />,
    chevron: <path d="m8 10 4 4 4-4" />,
    clock: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M12 7v5l3 2" />
      </>
    ),
    map: (
      <>
        <path d="m3 6 6-3 6 3 6-3v15l-6 3-6-3-6 3V6Z" />
        <path d="M9 3v15m6-12v15" />
      </>
    ),
    minus: <path d="M5 12h14" />,
    plus: <path d="M12 5v14m-7-7h14" />,
    phone: <path d="M7 3H4a1 1 0 0 0-1 1c0 9.4 7.6 17 17 17a1 1 0 0 0 1-1v-3l-4-2-2 2c-3.5-1.5-6.5-4.5-8-8l2-2-2-4Z" />,
    seat: (
      <>
        <path d="M7 12V6a3 3 0 0 1 6 0v6" />
        <path d="M5 10v5a3 3 0 0 0 3 3h9a2 2 0 0 0 2-2v-6M8 18v3m8-3v3" />
      </>
    ),
    swap: <path d="m7 7 3-3m-3 3 3 3M17 17l-3 3m3-3-3-3M9 7h8a2 2 0 0 1 2 2v1M15 17H7a2 2 0 0 1-2-2v-1" />,
    user: (
      <>
        <circle cx="12" cy="8" r="4" />
        <path d="M4 21a8 8 0 0 1 16 0" />
      </>
    ),
  };

  return (
    <svg
      aria-hidden="true"
      fill="none"
      height={size}
      viewBox="0 0 24 24"
      width={size}
      stroke="currentColor"
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="1.8"
    >
      {paths[name]}
    </svg>
  );
}

const trips = [
  {
    id: 1,
    operator: "Pacific Express",
    fromTime: "7:30 AM",
    toTime: "2:20 PM",
    duration: "6h 50m",
    price: 49,
    seats: 8,
    type: "Direct",
    features: ["Wi-Fi", "Power", "Reclining seats"],
  },
  {
    id: 2,
    operator: "Westline",
    fromTime: "9:15 AM",
    toTime: "4:35 PM",
    duration: "7h 20m",
    price: 42,
    seats: 12,
    type: "Direct",
    features: ["Wi-Fi", "Power", "Extra legroom"],
  },
  {
    id: 3,
    operator: "Coastal",
    fromTime: "10:45 PM",
    toTime: "5:55 AM",
    duration: "7h 10m",
    price: 38,
    seats: 5,
    type: "Overnight",
    features: ["Wi-Fi", "Restroom", "Blanket"],
  },
];

function App() {
  const [view, setView] = useState<"book" | "trips" | "help">("book");
  const [checkoutStep, setCheckoutStep] = useState<"results" | "seats" | "payment">("results");
  const [tripType, setTripType] = useState("One way");
  const [from, setFrom] = useState("San Francisco");
  const [to, setTo] = useState("Los Angeles");
  const [passengers, setPassengers] = useState(1);
  const [selected, setSelected] = useState(1);
  const [selectedSeats, setSelectedSeats] = useState<string[]>([]);
  const [booked, setBooked] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState("card");
  const [notice, setNotice] = useState("");

  const selectedTrip = useMemo(
    () => trips.find((trip) => trip.id === selected) ?? trips[0],
    [selected],
  );

  const swapCities = () => {
    setFrom(to);
    setTo(from);
  };

  const handleSearch = () => {
    setNotice(`Showing the best rides from ${from} to ${to}`);
    window.setTimeout(() => setNotice(""), 2800);
    document.getElementById("results")?.scrollIntoView({ behavior: "smooth" });
  };

  const navigate = (nextView: "book" | "trips" | "help") => {
    setView(nextView);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const toggleSeat = (seat: string) => {
    setSelectedSeats((current) =>
      current.includes(seat)
        ? current.filter((item) => item !== seat)
        : current.length < passengers
          ? [...current, seat]
          : current,
    );
  };

  const completePayment = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setBooked(true);
    setCheckoutStep("results");
    setView("trips");
    setNotice("Payment approved. Your trip is confirmed.");
    window.scrollTo({ top: 0, behavior: "smooth" });
    window.setTimeout(() => setNotice(""), 3200);
  };

  return (
    <main>
      <header className="topbar">
        <button className="brand brand-button" onClick={() => navigate("book")} type="button" aria-label="Rideon home">
          <span className="brand-mark"><Icon name="bus" size={22} /></span>
          <span>RIDEON</span>
        </button>
        <nav className="nav-links" aria-label="Main navigation">
          <button className={view === "book" ? "active" : ""} onClick={() => navigate("book")} type="button">Book a ride</button>
          <button className={view === "trips" ? "active" : ""} onClick={() => navigate("trips")} type="button">My trips</button>
          <button className={view === "help" ? "active" : ""} onClick={() => navigate("help")} type="button">Help</button>
        </nav>
        <button className="account-button" type="button">
          <Icon name="user" size={18} />
          <span>Account</span>
        </button>
      </header>

      {view === "book" && checkoutStep === "results" && <>
      <section className="hero" id="book">
        <div className="route-art" aria-hidden="true">
          <span className="art-stop art-stop-one" />
          <span className="art-stop art-stop-two" />
          <span className="art-stop art-stop-three" />
          <span className="art-bus"><Icon name="bus" size={26} /></span>
        </div>
        <div className="hero-copy">
          <p className="eyebrow"><span /> GO SOMEWHERE GOOD</p>
          <h1>Your next city is<br /><em>closer</em> than you think.</h1>
          <p className="hero-description">Simple fares. Comfy seats. Less waiting around.<br />Your journey starts right here.</p>
        </div>
        <div className="trust-note">
          <strong>4.9</strong>
          <span>Average rider rating</span>
          <div className="stars" aria-label="5 out of 5 stars">★★★★★</div>
        </div>
      </section>

      <section className="search-wrap" aria-label="Search bus tickets">
        <div className="search-card">
          <div className="trip-toggle" aria-label="Trip type">
            {["One way", "Round trip"].map((type) => (
              <button
                className={tripType === type ? "selected" : ""}
                key={type}
                onClick={() => setTripType(type)}
                type="button"
              >
                {type}
              </button>
            ))}
          </div>

          <div className="search-fields">
            <label className="field city-field">
              <span>FROM</span>
              <span className="field-value">
                <Icon name="map" size={20} />
                <input aria-label="From" onChange={(event) => setFrom(event.target.value)} value={from} />
              </span>
            </label>

            <button className="swap-button" onClick={swapCities} type="button" aria-label="Swap cities">
              <Icon name="swap" size={18} />
            </button>

            <label className="field city-field">
              <span>TO</span>
              <span className="field-value">
                <Icon name="map" size={20} />
                <input aria-label="To" onChange={(event) => setTo(event.target.value)} value={to} />
              </span>
            </label>

            <label className="field">
              <span>DEPART</span>
              <span className="field-value">
                <Icon name="calendar" size={20} />
                <input aria-label="Departure date" type="date" defaultValue="2025-05-23" />
              </span>
            </label>

            <div className="field passenger-field">
              <span>TRAVELERS</span>
              <div className="passenger-control">
                <button
                  aria-label="Remove passenger"
                  disabled={passengers === 1}
                  onClick={() => setPassengers((count) => Math.max(1, count - 1))}
                  type="button"
                >
                  <Icon name="minus" size={14} />
                </button>
                <strong>{passengers}</strong>
                <button
                  aria-label="Add passenger"
                  onClick={() => setPassengers((count) => Math.min(8, count + 1))}
                  type="button"
                >
                  <Icon name="plus" size={14} />
                </button>
              </div>
            </div>

            <button className="search-button" onClick={handleSearch} type="button">
              Find a ride <Icon name="arrow" size={20} />
            </button>
          </div>
        </div>
      </section>

      <section className="results-section" id="results">
        <div className="results-heading">
          <div>
            <p className="section-kicker">YOUR OPTIONS</p>
            <h2>San Francisco <span>to</span> Los Angeles</h2>
          </div>
          <p className="results-count">12 rides available</p>
        </div>

        <div className="date-strip">
          {[
            ["WED", "21"],
            ["THU", "22"],
            ["FRI", "23"],
            ["SAT", "24"],
            ["SUN", "25"],
          ].map(([day, date]) => (
            <button className={date === "23" ? "date-selected" : ""} key={date} type="button">
              <span>{day}</span>
              <strong>{date}</strong>
              <small>May</small>
            </button>
          ))}
        </div>

        <div className="results-layout">
          <div className="trip-list">
            {trips.map((trip, index) => (
              <article className={`trip-card ${selected === trip.id ? "trip-selected" : ""}`} key={trip.id}>
                {index === 0 && <span className="best-tag">BEST MATCH</span>}
                <div className="operator-row">
                  <div className="operator">
                    <span className="operator-icon"><Icon name="bus" size={18} /></span>
                    <strong>{trip.operator}</strong>
                  </div>
                  <span className="trip-type">{trip.type}</span>
                </div>
                <div className="trip-main">
                  <div className="time-block">
                    <strong>{trip.fromTime}</strong>
                    <span>San Francisco</span>
                  </div>
                  <div className="journey-line">
                    <span className="line-dot" />
                    <span className="line" />
                    <Icon name="bus" size={17} />
                    <span className="line" />
                    <span className="line-dot" />
                    <small><Icon name="clock" size={13} /> {trip.duration}</small>
                  </div>
                  <div className="time-block align-right">
                    <strong>{trip.toTime}</strong>
                    <span>Los Angeles</span>
                  </div>
                  <div className="price-block">
                    <span>from</span>
                    <strong><small>$</small>{trip.price}</strong>
                    <span>per person</span>
                  </div>
                </div>
                <div className="trip-footer">
                  <div className="features">
                    {trip.features.map((feature) => (
                      <span key={feature}><Icon name="check" size={13} /> {feature}</span>
                    ))}
                  </div>
                  <span className="seats-left"><Icon name="seat" size={16} /> {trip.seats} seats left</span>
                  <button onClick={() => setSelected(trip.id)} type="button">
                    {selected === trip.id ? "Selected" : "Choose ride"}
                    <Icon name={selected === trip.id ? "check" : "arrow"} size={17} />
                  </button>
                </div>
              </article>
            ))}
          </div>

          <aside className="booking-summary">
            <p className="section-kicker">YOUR TRIP</p>
            <h3>Ready when you are.</h3>
            <div className="summary-route">
              <div><span /><p><strong>{selectedTrip.fromTime}</strong>San Francisco</p></div>
              <i />
              <div><span /><p><strong>{selectedTrip.toTime}</strong>Los Angeles</p></div>
            </div>
            <div className="summary-meta">
              <span><Icon name="calendar" size={16} /> Fri, May 23</span>
              <span><Icon name="clock" size={16} /> {selectedTrip.duration}</span>
              <span><Icon name="user" size={16} /> {passengers} traveler{passengers > 1 ? "s" : ""}</span>
            </div>
            <div className="summary-total">
              <span>Total</span>
              <strong>${selectedTrip.price * passengers}</strong>
            </div>
            <button type="button" onClick={() => {
              setSelectedSeats([]);
              setCheckoutStep("seats");
              window.scrollTo({ top: 0, behavior: "smooth" });
            }}>
              Continue to seats <Icon name="arrow" size={19} />
            </button>
            <small>No booking fees. Cancel up to 24 hours before departure.</small>
          </aside>
        </div>
      </section>
      </>}

      {view === "book" && checkoutStep === "seats" && (
        <section className="checkout-page">
          <div className="checkout-header">
            <button className="back-button" onClick={() => setCheckoutStep("results")} type="button">← Back to rides</button>
            <p className="section-kicker">STEP 1 OF 2</p>
            <h2>Choose your seat</h2>
            <p>Select {passengers} seat{passengers > 1 ? "s" : ""} for your trip to Los Angeles.</p>
          </div>
          <div className="checkout-layout">
            <div className="seat-card">
              <div className="bus-front"><Icon name="bus" size={20} /><span>FRONT OF BUS</span></div>
              <div className="seat-legend">
                <span><i className="seat-swatch available" /> Available</span>
                <span><i className="seat-swatch chosen" /> Selected</span>
                <span><i className="seat-swatch unavailable" /> Unavailable</span>
              </div>
              <div className="seat-grid" aria-label="Select seats">
                {Array.from({ length: 32 }, (_, index) => {
                  const row = Math.floor(index / 4) + 1;
                  const letter = ["A", "B", "C", "D"][index % 4];
                  const seat = `${row}${letter}`;
                  const unavailable = ["1A", "2C", "3D", "4A", "5B", "6C", "7D"].includes(seat);
                  return (
                    <button
                      aria-label={`Seat ${seat}`}
                      className={`${selectedSeats.includes(seat) ? "selected-seat" : ""} ${unavailable ? "unavailable-seat" : ""}`}
                      disabled={unavailable}
                      key={seat}
                      onClick={() => toggleSeat(seat)}
                      type="button"
                    >
                      <Icon name="seat" size={18} /><span>{seat}</span>
                    </button>
                  );
                })}
              </div>
              <div className="bus-rear">RESTROOM <span>•</span> REAR EXIT</div>
            </div>
            <aside className="checkout-summary">
              <p className="section-kicker">TRIP SUMMARY</p>
              <h3>{selectedTrip.operator}</h3>
              <div className="checkout-route">
                <strong>{selectedTrip.fromTime}</strong><span>San Francisco</span>
                <i />
                <strong>{selectedTrip.toTime}</strong><span>Los Angeles</span>
              </div>
              <div className="seat-selection">
                <span>Selected seats</span>
                <strong>{selectedSeats.length ? selectedSeats.join(", ") : "None yet"}</strong>
              </div>
              <div className="checkout-total"><span>Total</span><strong>${selectedTrip.price * passengers}</strong></div>
              <button
                disabled={selectedSeats.length !== passengers}
                onClick={() => {
                  setCheckoutStep("payment");
                  window.scrollTo({ top: 0, behavior: "smooth" });
                }}
                type="button"
              >
                Continue to payment <Icon name="arrow" size={18} />
              </button>
              {selectedSeats.length !== passengers && <small>Select {passengers - selectedSeats.length} more seat{passengers - selectedSeats.length !== 1 ? "s" : ""} to continue</small>}
            </aside>
          </div>
        </section>
      )}

      {view === "book" && checkoutStep === "payment" && (
        <section className="checkout-page payment-page">
          <div className="checkout-header">
            <button className="back-button" onClick={() => setCheckoutStep("seats")} type="button">← Back to seats</button>
            <p className="section-kicker">STEP 2 OF 2</p>
            <h2>Secure payment</h2>
            <p>Your card is encrypted and your booking is confirmed instantly.</p>
          </div>
          <div className="payment-layout">
            <form className="payment-form" onSubmit={completePayment}>
              <div className="payment-methods">
                <button className={paymentMethod === "card" ? "method-selected" : ""} onClick={() => setPaymentMethod("card")} type="button"><Icon name="card" size={20} /> Card</button>
                <button className={paymentMethod === "wallet" ? "method-selected" : ""} onClick={() => setPaymentMethod("wallet")} type="button">Digital wallet</button>
              </div>
              <label><span>EMAIL FOR TICKET</span><input required type="email" placeholder="you@example.com" /></label>
              <label><span>NAME ON CARD</span><input required placeholder="Full name" /></label>
              <label><span>CARD NUMBER</span><div className="input-with-icon"><Icon name="card" size={19} /><input required inputMode="numeric" placeholder="4242 4242 4242 4242" minLength={15} /></div></label>
              <div className="split-fields">
                <label><span>EXPIRY DATE</span><input required placeholder="MM / YY" /></label>
                <label><span>SECURITY CODE</span><input required inputMode="numeric" placeholder="CVV" minLength={3} /></label>
              </div>
              <button className="pay-button" type="submit">Pay ${selectedTrip.price * passengers} securely <Icon name="arrow" size={19} /></button>
              <p className="secure-note"><Icon name="check" size={15} /> Secure 256-bit encrypted payment</p>
            </form>
            <aside className="order-card">
              <p className="section-kicker">ORDER SUMMARY</p>
              <h3>San Francisco <span>to</span> Los Angeles</h3>
              <div className="order-detail"><span>Fri, May 23</span><span>{selectedTrip.fromTime} – {selectedTrip.toTime}</span></div>
              <div className="order-detail"><span>{selectedTrip.operator}</span><span>Seats {selectedSeats.join(", ")}</span></div>
              <div className="order-price"><span>{passengers} × ticket</span><strong>${selectedTrip.price * passengers}</strong></div>
              <small>Taxes and booking fees included</small>
            </aside>
          </div>
        </section>
      )}

      {view === "trips" && (
        <section className="dashboard-page">
          <div className="page-heading">
            <p className="section-kicker">MY TRIPS</p>
            <h1>Where you're headed.</h1>
            <p>Everything you need for your upcoming journeys, all in one place.</p>
          </div>
          <div className="trip-tabs"><button className="active" type="button">Upcoming</button><button type="button">Past</button></div>
          {booked && (
            <article className="my-trip-card new-booking">
              <div className="ticket-status"><Icon name="check" size={16} /> CONFIRMED</div>
              <div className="ticket-date"><span>MAY</span><strong>23</strong><small>FRIDAY</small></div>
              <div className="ticket-route">
                <p>{selectedTrip.fromTime}<strong>San Francisco</strong></p>
                <div><span /><i /><Icon name="bus" size={20} /><i /><span /></div>
                <p>{selectedTrip.toTime}<strong>Los Angeles</strong></p>
              </div>
              <div className="ticket-info"><span>SEAT<strong>{selectedSeats.join(", ")}</strong></span><span>BOOKING ID<strong>RD8K21</strong></span></div>
              <button type="button">View ticket <Icon name="arrow" size={17} /></button>
            </article>
          )}
          <article className="my-trip-card">
            <div className="ticket-status"><Icon name="check" size={16} /> CONFIRMED</div>
            <div className="ticket-date"><span>JUN</span><strong>08</strong><small>SUNDAY</small></div>
            <div className="ticket-route">
              <p>8:10 AM<strong>Seattle</strong></p>
              <div><span /><i /><Icon name="bus" size={20} /><i /><span /></div>
              <p>11:45 AM<strong>Portland</strong></p>
            </div>
            <div className="ticket-info"><span>SEAT<strong>6A</strong></span><span>BOOKING ID<strong>RD4F92</strong></span></div>
            <button type="button">View ticket <Icon name="arrow" size={17} /></button>
          </article>
          <button className="book-another" onClick={() => navigate("book")} type="button">Book another ride <Icon name="arrow" size={18} /></button>
        </section>
      )}

      {view === "help" && (
        <section className="help-page">
          <div className="page-heading">
            <p className="section-kicker">HELP CENTER</p>
            <h1>We're here for the journey.</h1>
            <p>Questions about a booking, baggage, or your route? Talk to a real person.</p>
          </div>
          <div className="support-grid">
            <div className="support-card primary-support">
              <span className="support-icon"><Icon name="phone" size={26} /></span>
              <p>24/7 CUSTOMER CARE</p>
              <a href="tel:+1800743366">1-800-RIDE-ON</a>
              <strong>1-800-743-366</strong>
              <small>Average wait time: under 2 minutes</small>
            </div>
            <div className="support-card">
              <span className="support-icon"><Icon name="card" size={26} /></span>
              <p>BOOKING SUPPORT</p>
              <h3>Manage your trip</h3>
              <small>Change seats, update passenger details, or cancel a ride.</small>
              <button onClick={() => navigate("trips")} type="button">Go to my trips <Icon name="arrow" size={17} /></button>
            </div>
          </div>
          <div className="faq-list">
            <h2>Common questions</h2>
            {["Can I change or cancel my ticket?", "How much baggage can I bring?", "When should I arrive at the stop?"].map((question) => (
              <details key={question}><summary>{question}<span>+</span></summary><p>Call our customer care team at 1-800-743-366 and we'll help you with your booking.</p></details>
            ))}
          </div>
        </section>
      )}

      <footer>
        <a className="brand footer-brand" href="#">
          <span className="brand-mark"><Icon name="bus" size={20} /></span>
          <span>RIDEON</span>
        </a>
        <p>Better bus travel, city to city.</p>
        <span>© 2025 Rideon</span>
      </footer>

      {notice && <div className="toast"><Icon name="check" size={18} /> {notice}</div>}
    </main>
  );
}

export default App;
