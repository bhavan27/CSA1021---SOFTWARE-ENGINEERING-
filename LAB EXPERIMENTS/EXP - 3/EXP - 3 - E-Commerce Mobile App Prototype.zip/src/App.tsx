import { useEffect, useMemo, useState } from "react";

type Screen =
  | "splash"
  | "onboarding"
  | "home"
  | "categories"
  | "search"
  | "listing"
  | "filters"
  | "product"
  | "wishlist"
  | "cart"
  | "checkout"
  | "confirmation"
  | "profile";

type Product = {
  id: number;
  name: string;
  short: string;
  price: number;
  original: number;
  rating: number;
  reviews: number;
  image: string;
  color: string;
};

const products: Product[] = [
  {
    id: 1,
    name: "AeroSound Max",
    short: "Wireless headphones",
    price: 129.99,
    original: 179.99,
    rating: 4.8,
    reviews: 126,
    image:
      "https://images.unsplash.com/photo-1677019758448-4c34a78df2c3?auto=format&fit=crop&w=900&q=85",
    color: "bg-[#e8eff2]",
  },
  {
    id: 2,
    name: "Cloud Runner",
    short: "Everyday sneakers",
    price: 89.99,
    original: 119.99,
    rating: 4.6,
    reviews: 94,
    image:
      "https://images.unsplash.com/photo-1735653192947-286d43cc05c6?auto=format&fit=crop&w=900&q=85",
    color: "bg-[#eeeae6]",
  },
  {
    id: 3,
    name: "One Eau de Parfum",
    short: "Fresh woody fragrance",
    price: 64.99,
    original: 79.99,
    rating: 4.9,
    reviews: 208,
    image:
      "https://images.unsplash.com/photo-1620848616916-3efaf499adcb?auto=format&fit=crop&w=900&q=85",
    color: "bg-[#ebe9e2]",
  },
  {
    id: 4,
    name: "Glow Ritual Set",
    short: "Skincare essentials",
    price: 48.0,
    original: 60.0,
    rating: 4.7,
    reviews: 81,
    image:
      "https://images.unsplash.com/photo-1622618991746-fe6004db3a47?auto=format&fit=crop&w=900&q=85",
    color: "bg-[#f6edcf]",
  },
  {
    id: 5,
    name: "Studio Buds",
    short: "True wireless earbuds",
    price: 99.0,
    original: 129.0,
    rating: 4.5,
    reviews: 168,
    image:
      "https://images.unsplash.com/photo-1777216794963-faf02512cf7f?auto=format&fit=crop&w=900&q=85",
    color: "bg-[#f3e2d4]",
  },
  {
    id: 6,
    name: "Nomad Essentials",
    short: "Travel accessories",
    price: 74.5,
    original: 96.0,
    rating: 4.8,
    reviews: 53,
    image:
      "https://images.unsplash.com/photo-1755719401538-79bea384b393?auto=format&fit=crop&w=900&q=85",
    color: "bg-[#e7dfd3]",
  },
];

const categories = [
  ["Electronics", "headphones"],
  ["Fashion", "shirt"],
  ["Shoes", "shoe"],
  ["Beauty", "sparkles"],
  ["Home", "home"],
  ["Sports", "activity"],
  ["Accessories", "watch"],
];

const paths: Record<string, React.ReactNode> = {
  home: <><path d="m3 11 9-8 9 8" /><path d="M5 10v10h14V10" /><path d="M9 20v-6h6v6" /></>,
  grid: <><rect x="3" y="3" width="7" height="7" rx="2" /><rect x="14" y="3" width="7" height="7" rx="2" /><rect x="3" y="14" width="7" height="7" rx="2" /><rect x="14" y="14" width="7" height="7" rx="2" /></>,
  heart: <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1.1L12 21l7.8-7.5 1.1-1.1a5.5 5.5 0 0 0-.1-7.8Z" />,
  bag: <><path d="M6 8h12l1 13H5L6 8Z" /><path d="M9 9V6a3 3 0 0 1 6 0v3" /></>,
  user: <><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></>,
  search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-4-4" /></>,
  bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9" /><path d="M10 21h4" /></>,
  pin: <><path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z" /><circle cx="12" cy="10" r="2" /></>,
  chevron: <path d="m9 18 6-6-6-6" />,
  down: <path d="m6 9 6 6 6-6" />,
  back: <><path d="m15 18-6-6 6-6" /></>,
  star: <path d="m12 2 3 6 7 .9-5 4.8 1.3 6.8L12 17.3l-6.3 3.2L7 13.7 2 8.9 9 8l3-6Z" />,
  filter: <><path d="M4 6h16M7 12h10M10 18h4" /></>,
  sliders: <><path d="M4 6h16M4 12h16M4 18h16" /><circle cx="8" cy="6" r="2" fill="white" /><circle cx="16" cy="12" r="2" fill="white" /><circle cx="11" cy="18" r="2" fill="white" /></>,
  close: <><path d="m6 6 12 12M18 6 6 18" /></>,
  plus: <><path d="M12 5v14M5 12h14" /></>,
  minus: <path d="M5 12h14" />,
  trash: <><path d="M4 7h16M9 7V4h6v3M7 7l1 14h8l1-14" /></>,
  check: <path d="m5 12 4 4L19 6" />,
  card: <><rect x="3" y="5" width="18" height="14" rx="2" /><path d="M3 10h18" /></>,
  cash: <><rect x="3" y="6" width="18" height="12" rx="2" /><circle cx="12" cy="12" r="3" /></>,
  truck: <><path d="M3 6h11v11H3zM14 10h4l3 3v4h-7z" /><circle cx="7" cy="19" r="2" /><circle cx="18" cy="19" r="2" /></>,
  box: <><path d="m3 7 9-4 9 4-9 4-9-4Z" /><path d="M3 7v10l9 4 9-4V7M12 11v10" /></>,
  shield: <><path d="M12 3 4 6v5c0 5 3.4 8.8 8 10 4.6-1.2 8-5 8-10V6l-8-3Z" /><path d="m9 12 2 2 4-4" /></>,
  coupon: <><path d="M4 5h16v5a2 2 0 0 0 0 4v5H4v-5a2 2 0 0 0 0-4V5Z" /><path d="M12 7v10" /></>,
  camera: <><path d="M4 8h3l2-3h6l2 3h3v11H4V8Z" /><circle cx="12" cy="13" r="3" /></>,
  settings: <><circle cx="12" cy="12" r="3" /><path d="M19 12a7 7 0 0 0-.1-1l2-1.5-2-3.4-2.4 1A8 8 0 0 0 15 6l-.3-2.6h-4L10.4 6A8 8 0 0 0 8 7.1l-2.4-1-2 3.4 2 1.5a7 7 0 0 0 0 2l-2 1.5 2 3.4 2.4-1A8 8 0 0 0 10 18l.3 2.6h4L15 18a8 8 0 0 0 1.4-1.1l2.4 1 2-3.4-2-1.5c.1-.3.2-.7.2-1Z" /></>,
  help: <><circle cx="12" cy="12" r="9" /><path d="M9.5 9a2.7 2.7 0 1 1 4.2 2.2c-1 .7-1.7 1.1-1.7 2.8M12 18h.01" /></>,
  logout: <><path d="M10 4H4v16h6M14 8l4 4-4 4M8 12h10" /></>,
  shirt: <path d="m8 4 4 2 4-2 5 4-3 4-2-2v11H8V10l-2 2-3-4 5-4Z" />,
  shoe: <path d="M4 14c3 0 5-4 6-8l4 6 6 2v4H4v-4Z" />,
  sparkles: <><path d="m12 3 1.5 4.5L18 9l-4.5 1.5L12 15l-1.5-4.5L6 9l4.5-1.5L12 3Z" /><path d="m19 15 .8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8L19 15Z" /></>,
  activity: <><path d="M4 12h3l2-5 4 10 2-5h5" /></>,
  watch: <><rect x="8" y="6" width="8" height="12" rx="3" /><path d="m10 6 1-3h2l1 3M10 18l1 3h2l1-3" /></>,
  headphones: <><path d="M4 14v-2a8 8 0 0 1 16 0v2" /><rect x="3" y="13" width="4" height="7" rx="2" /><rect x="17" y="13" width="4" height="7" rx="2" /></>,
};

function Icon({ name, size = 20, filled = false }: { name: string; size?: number; filled?: boolean }) {
  return (
    <svg
      aria-hidden="true"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill={filled ? "currentColor" : "none"}
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {paths[name] ?? paths.box}
    </svg>
  );
}

function Btn({
  children,
  onClick,
  variant = "primary",
  className = "",
  disabled = false,
}: {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: "primary" | "secondary" | "ghost" | "dark";
  className?: string;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      className={`btn btn-${variant} ${className}`}
    >
      {children}
    </button>
  );
}

function IconBtn({
  icon,
  label,
  onClick,
  active = false,
  className = "",
}: {
  icon: string;
  label: string;
  onClick?: () => void;
  active?: boolean;
  className?: string;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      onClick={onClick}
      className={`icon-btn ${active ? "active" : ""} ${className}`}
    >
      <Icon name={icon} size={20} filled={active && icon === "heart"} />
    </button>
  );
}

function Header({
  title,
  onBack,
  right,
  eyebrow,
}: {
  title: string;
  onBack?: () => void;
  right?: React.ReactNode;
  eyebrow?: string;
}) {
  return (
    <div className="sticky top-0 z-20 flex min-h-16 items-center gap-3 border-b border-stone-200/70 bg-[#fbfaf7]/95 px-5 backdrop-blur-xl">
      {onBack && <IconBtn icon="back" label="Go back" onClick={onBack} />}
      <div className="min-w-0 flex-1">
        {eyebrow && <div className="text-[11px] font-semibold uppercase tracking-[.18em] text-stone-400">{eyebrow}</div>}
        <div className="truncate text-[18px] font-bold tracking-[-.02em] text-[#171614]">{title}</div>
      </div>
      {right}
    </div>
  );
}

function SearchBar({ onClick, value }: { onClick?: () => void; value?: string }) {
  return (
    <button type="button" onClick={onClick} className="search-bar">
      <Icon name="search" size={19} />
      <span className={value ? "text-stone-800" : "text-stone-400"}>{value || "Search products, brands..."}</span>
      <span className="ml-auto rounded-lg bg-white p-1.5 text-stone-500 shadow-sm"><Icon name="sliders" size={17} /></span>
    </button>
  );
}

function Rating({ value, reviews }: { value: number; reviews?: number }) {
  return (
    <div className="flex items-center gap-1 text-xs font-semibold text-stone-600">
      <span className="text-amber-400"><Icon name="star" size={13} filled /></span>
      {value}
      {reviews !== undefined && <span className="font-medium text-stone-400">({reviews})</span>}
    </div>
  );
}

function Price({ product, large = false }: { product: Product; large?: boolean }) {
  const discount = Math.round((1 - product.price / product.original) * 100);
  return (
    <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
      <span className={large ? "text-2xl font-extrabold tracking-tight" : "text-[15px] font-extrabold"}>${product.price.toFixed(2)}</span>
      <span className={large ? "text-sm text-stone-400 line-through" : "text-xs text-stone-400 line-through"}>${product.original.toFixed(2)}</span>
      {large && <span className="rounded-md bg-emerald-50 px-2 py-1 text-xs font-bold text-emerald-700">{discount}% OFF</span>}
    </div>
  );
}

function ProductCard({
  product,
  onOpen,
  wished,
  onWish,
}: {
  product: Product;
  onOpen: () => void;
  wished: boolean;
  onWish: () => void;
}) {
  const discount = Math.round((1 - product.price / product.original) * 100);
  return (
    <div className="product-card">
      <button type="button" onClick={onOpen} className={`relative block aspect-[1/1.08] w-full overflow-hidden rounded-[20px] ${product.color}`}>
        <img src={product.image} alt={product.name} className="h-full w-full object-cover transition duration-500 hover:scale-105" />
        <span className="absolute left-2.5 top-2.5 rounded-full bg-[#171614] px-2 py-1 text-[10px] font-bold text-white">{discount}% off</span>
      </button>
      <IconBtn icon="heart" label="Toggle wishlist" active={wished} onClick={onWish} className="absolute right-2.5 top-2.5 bg-white/90" />
      <button type="button" onClick={onOpen} className="block w-full px-1 pt-3 text-left">
        <div className="mb-1 line-clamp-1 text-sm font-bold text-[#171614]">{product.name}</div>
        <Rating value={product.rating} reviews={product.reviews} />
        <div className="mt-2"><Price product={product} /></div>
      </button>
    </div>
  );
}

function BottomNav({ screen, go, cartCount }: { screen: Screen; go: (s: Screen) => void; cartCount: number }) {
  const items: [Screen, string, string][] = [
    ["home", "home", "Home"],
    ["categories", "grid", "Categories"],
    ["wishlist", "heart", "Wishlist"],
    ["cart", "bag", "Cart"],
    ["profile", "user", "Profile"],
  ];
  return (
    <div className="bottom-nav">
      {items.map(([target, icon, label]) => (
        <button type="button" key={target} onClick={() => go(target)} className={`nav-item ${screen === target ? "selected" : ""}`}>
          <span className="relative">
            <Icon name={icon} size={21} filled={screen === target && icon === "heart"} />
            {target === "cart" && cartCount > 0 && <span className="cart-dot">{cartCount}</span>}
          </span>
          <span>{label}</span>
        </button>
      ))}
    </div>
  );
}

function Logo({ light = false }: { light?: boolean }) {
  return (
    <div className={`flex items-center gap-2.5 ${light ? "text-white" : "text-[#171614]"}`}>
      <span className="grid h-9 w-9 place-items-center rounded-xl bg-[#ff5b4d] text-white shadow-[0_8px_24px_rgba(255,91,77,.28)]">
        <Icon name="bag" size={19} />
      </span>
      <span className="text-xl font-extrabold tracking-[-.04em]">ShopEase</span>
    </div>
  );
}

function Splash() {
  return (
    <div className="relative flex min-h-[100dvh] flex-col items-center justify-center overflow-hidden bg-[#171614] text-white">
      <div className="absolute -right-24 -top-24 h-64 w-64 rounded-full bg-[#ff5b4d]/30 blur-3xl" />
      <div className="absolute -bottom-24 -left-20 h-72 w-72 rounded-full bg-amber-300/15 blur-3xl" />
      <div className="mb-9 grid h-28 w-28 place-items-center rounded-[34px] bg-[#ff5b4d] shadow-[0_24px_80px_rgba(255,91,77,.4)]">
        <Icon name="bag" size={52} />
      </div>
      <div className="text-4xl font-black tracking-[-.06em]">ShopEase</div>
      <div className="mt-3 text-sm font-medium text-stone-400">Everything you love, in one place.</div>
      <div className="absolute bottom-14 flex gap-1.5">
        <span className="loading-dot" /><span className="loading-dot delay-1" /><span className="loading-dot delay-2" />
      </div>
    </div>
  );
}

const onboarding = [
  {
    title: "Find your next favorite",
    text: "Discover curated products from brands you love, tailored to your style.",
    image: "https://images.unsplash.com/photo-1760565030243-c92ed557e8da?auto=format&fit=crop&w=1000&q=85",
    badge: "Discover",
  },
  {
    title: "Compare with confidence",
    text: "See ratings, prices and offers side by side, so every choice feels right.",
    image: "https://images.unsplash.com/photo-1755719401603-159a4eee8c57?auto=format&fit=crop&w=1000&q=85",
    badge: "Compare",
  },
  {
    title: "Checkout in a heartbeat",
    text: "Secure payments, saved details and real-time delivery updates make it effortless.",
    image: "https://images.unsplash.com/photo-1604118464816-5e2bd7b863c2?auto=format&fit=crop&w=1000&q=85",
    badge: "Shop securely",
  },
];

function Onboarding({ finish }: { finish: () => void }) {
  const [step, setStep] = useState(0);
  const data = onboarding[step];
  return (
    <div className="flex min-h-[100dvh] flex-col bg-[#fbfaf7] p-5">
      <div className="flex h-12 items-center justify-between">
        <Logo />
        <button type="button" onClick={finish} className="text-sm font-bold text-stone-500">Skip</button>
      </div>
      <div className="relative mt-5 flex-1 overflow-hidden rounded-[32px] bg-stone-100">
        <img key={data.image} src={data.image} alt="" className="onboard-image h-full min-h-[430px] w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/65 via-black/5 to-transparent" />
        <span className="absolute left-5 top-5 rounded-full bg-white/90 px-3 py-1.5 text-xs font-bold text-[#ff5b4d] backdrop-blur">{data.badge}</span>
        <div className="absolute bottom-0 p-6 text-white">
          <div className="text-[34px] font-black leading-[1.03] tracking-[-.05em]">{data.title}</div>
          <div className="mt-3 max-w-sm text-[15px] leading-6 text-white/80">{data.text}</div>
        </div>
      </div>
      <div className="flex items-center gap-2 py-6">
        <div className="flex flex-1 gap-2">
          {onboarding.map((_, i) => <span key={i} className={`h-1.5 rounded-full transition-all ${i === step ? "w-7 bg-[#ff5b4d]" : "w-2 bg-stone-300"}`} />)}
        </div>
        <Btn onClick={() => step === 2 ? finish() : setStep(step + 1)} className="min-w-36">
          {step === 2 ? "Get Started" : <>Next <Icon name="chevron" size={18} /></>}
        </Btn>
      </div>
    </div>
  );
}

function Home({
  go,
  openProduct,
  wishlist,
  toggleWish,
}: {
  go: (s: Screen) => void;
  openProduct: (p: Product) => void;
  wishlist: number[];
  toggleWish: (id: number) => void;
}) {
  return (
    <div className="pb-28">
      <div className="px-5 pt-5">
        <div className="flex items-center justify-between">
          <Logo />
          <div className="relative"><IconBtn icon="bell" label="Notifications" /><span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full border-2 border-[#fbfaf7] bg-[#ff5b4d]" /></div>
        </div>
        <button type="button" className="mt-6 flex items-center gap-2 text-left">
          <span className="grid h-9 w-9 place-items-center rounded-full bg-[#fff0ed] text-[#ff5b4d]"><Icon name="pin" size={17} /></span>
          <span><span className="block text-[11px] font-medium text-stone-400">Deliver to</span><span className="flex items-center gap-1 text-sm font-bold">Brooklyn, New York <Icon name="down" size={14} /></span></span>
        </button>
        <div className="mt-5"><SearchBar onClick={() => go("search")} /></div>
      </div>

      <div className="mx-5 mt-5 overflow-hidden rounded-[28px] bg-[#171614] text-white">
        <div className="relative min-h-48">
          <img src="https://images.unsplash.com/photo-1760565030346-4b947220fe3a?auto=format&fit=crop&w=1000&q=85" alt="Shopping bags" className="absolute inset-0 h-full w-full object-cover opacity-60" />
          <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/55 to-transparent" />
          <div className="relative z-10 w-3/5 p-6">
            <div className="text-[11px] font-extrabold uppercase tracking-[.2em] text-[#ff8b80]">Weekend Edit</div>
            <div className="mt-2 text-3xl font-black leading-none tracking-[-.05em]">Fresh finds.<br />Better prices.</div>
            <Btn onClick={() => go("listing")} variant="secondary" className="mt-5 !h-10 !px-4 !text-xs">Shop up to 40% off</Btn>
          </div>
        </div>
      </div>

      <SectionTitle title="Shop by category" action="See all" onClick={() => go("categories")} />
      <div className="no-scrollbar flex gap-4 overflow-x-auto px-5 pb-2">
        {categories.slice(0, 6).map(([name, icon]) => (
          <button type="button" key={name} onClick={() => go("listing")} className="shrink-0 text-center">
            <span className="mx-auto grid h-16 w-16 place-items-center rounded-[20px] border border-stone-200 bg-white text-stone-700 shadow-sm"><Icon name={icon} size={25} /></span>
            <span className="mt-2 block text-[11px] font-semibold text-stone-600">{name}</span>
          </button>
        ))}
      </div>

      <SectionTitle title="Popular products" action="See all" onClick={() => go("listing")} />
      <div className="no-scrollbar flex gap-4 overflow-x-auto px-5 pb-2">
        {products.slice(0, 4).map((p) => (
          <div key={p.id} className="w-[46%] shrink-0">
            <ProductCard product={p} onOpen={() => openProduct(p)} wished={wishlist.includes(p.id)} onWish={() => toggleWish(p.id)} />
          </div>
        ))}
      </div>

      <SectionTitle title="Recommended for you" />
      <div className="grid grid-cols-2 gap-x-4 gap-y-7 px-5">
        {products.slice(2, 6).map((p) => <ProductCard key={p.id} product={p} onOpen={() => openProduct(p)} wished={wishlist.includes(p.id)} onWish={() => toggleWish(p.id)} />)}
      </div>
    </div>
  );
}

function SectionTitle({ title, action, onClick }: { title: string; action?: string; onClick?: () => void }) {
  return (
    <div className="flex items-end justify-between px-5 pb-4 pt-7">
      <div className="text-xl font-extrabold tracking-[-.035em] text-[#171614]">{title}</div>
      {action && <button type="button" onClick={onClick} className="text-xs font-bold text-[#ff5b4d]">{action}</button>}
    </div>
  );
}

function Categories({ go }: { go: (s: Screen) => void }) {
  const colors = ["bg-[#e8eef4]", "bg-[#f6e7df]", "bg-[#e8eadf]", "bg-[#f4e5eb]", "bg-[#ede7dc]", "bg-[#e3edeb]", "bg-[#eee6f2]"];
  return (
    <div className="pb-28">
      <Header title="Categories" right={<IconBtn icon="search" label="Search" onClick={() => go("search")} />} />
      <div className="px-5 pt-5">
        <div className="mb-6 text-sm leading-6 text-stone-500">Browse collections handpicked for every part of your life.</div>
        <div className="grid grid-cols-2 gap-4">
          {categories.map(([name, icon], i) => (
            <button type="button" key={name} onClick={() => go("listing")} className={`group relative min-h-40 overflow-hidden rounded-[24px] p-5 text-left ${colors[i]}`}>
              <span className="grid h-11 w-11 place-items-center rounded-2xl bg-white/80 text-stone-700 shadow-sm"><Icon name={icon} size={23} /></span>
              <span className="absolute bottom-5 left-5">
                <span className="block text-[17px] font-extrabold tracking-tight text-stone-900">{name}</span>
                <span className="mt-1 block text-xs font-medium text-stone-500">{32 + i * 17} items</span>
              </span>
              <span className="absolute -bottom-8 -right-7 h-24 w-24 rounded-full border-[16px] border-white/40 transition-transform group-hover:scale-125" />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

function SearchScreen({
  go,
  openProduct,
  wishlist,
  toggleWish,
}: {
  go: (s: Screen) => void;
  openProduct: (p: Product) => void;
  wishlist: number[];
  toggleWish: (id: number) => void;
}) {
  const [query, setQuery] = useState("");
  const [searched, setSearched] = useState(false);
  const doSearch = () => { if (query.trim()) setSearched(true); };
  return (
    <div className="pb-28">
      <Header title="Search" onBack={() => go("home")} />
      <div className="px-5 pt-5">
        <div className="flex gap-2">
          <label className="search-input">
            <Icon name="search" size={19} />
            <input autoFocus value={query} onChange={(e) => setQuery(e.target.value)} onKeyDown={(e) => e.key === "Enter" && doSearch()} placeholder="What are you looking for?" />
            {query && <button type="button" aria-label="Clear search" onClick={() => { setQuery(""); setSearched(false); }}><Icon name="close" size={17} /></button>}
          </label>
          <IconBtn icon="sliders" label="Filters" onClick={() => go("filters")} className="!h-12 !w-12 !rounded-2xl bg-[#171614] text-white" />
        </div>
        {searched ? (
          <>
            <div className="flex items-center justify-between py-6">
              <div><div className="text-lg font-extrabold">Results for “{query}”</div><div className="mt-1 text-xs text-stone-400">24 products found</div></div>
              <button type="button" className="flex items-center gap-1 text-xs font-bold">Sort <Icon name="down" size={14} /></button>
            </div>
            <div className="grid grid-cols-2 gap-x-4 gap-y-7">
              {products.map((p) => <ProductCard key={p.id} product={p} onOpen={() => openProduct(p)} wished={wishlist.includes(p.id)} onWish={() => toggleWish(p.id)} />)}
            </div>
          </>
        ) : (
          <>
            <SectionInner title="Recent searches" action="Clear all">
              <div className="space-y-1">
                {["Wireless headphones", "White sneakers", "Skincare set"].map((x) => (
                  <button type="button" key={x} onClick={() => { setQuery(x); setSearched(true); }} className="flex w-full items-center gap-3 rounded-xl py-3 text-sm font-medium text-stone-700">
                    <span className="grid h-8 w-8 place-items-center rounded-full bg-stone-100 text-stone-400"><Icon name="search" size={15} /></span>{x}<span className="ml-auto text-stone-300"><Icon name="chevron" size={16} /></span>
                  </button>
                ))}
              </div>
            </SectionInner>
            <SectionInner title="Popular searches">
              <div className="flex flex-wrap gap-2">
                {["Summer sale", "Smart watch", "Running shoes", "Perfume", "Home decor", "Travel gear"].map((x) => (
                  <button type="button" key={x} onClick={() => { setQuery(x); setSearched(true); }} className="rounded-full border border-stone-200 bg-white px-4 py-2.5 text-xs font-semibold text-stone-600">{x}</button>
                ))}
              </div>
            </SectionInner>
            <SectionInner title="Trending now">
              <div className="grid grid-cols-2 gap-4">
                {products.slice(0, 2).map((p) => <ProductCard key={p.id} product={p} onOpen={() => openProduct(p)} wished={wishlist.includes(p.id)} onWish={() => toggleWish(p.id)} />)}
              </div>
            </SectionInner>
          </>
        )}
      </div>
    </div>
  );
}

function SectionInner({ title, action, children }: { title: string; action?: string; children: React.ReactNode }) {
  return (
    <div className="pt-7">
      <div className="mb-4 flex items-center justify-between">
        <div className="text-lg font-extrabold tracking-tight">{title}</div>
        {action && <button type="button" className="text-xs font-bold text-[#ff5b4d]">{action}</button>}
      </div>
      {children}
    </div>
  );
}

function Listing({
  go,
  openProduct,
  wishlist,
  toggleWish,
  filtered,
}: {
  go: (s: Screen) => void;
  openProduct: (p: Product) => void;
  wishlist: number[];
  toggleWish: (id: number) => void;
  filtered: boolean;
}) {
  const [sortOpen, setSortOpen] = useState(false);
  const [sort, setSort] = useState("Recommended");
  const shown = filtered ? products.filter((p) => p.rating >= 4.7) : products;
  return (
    <div className="pb-24">
      <Header title="Electronics" onBack={() => go("categories")} right={<IconBtn icon="search" label="Search" onClick={() => go("search")} />} />
      <div className="px-5 pt-4">
        <div className="text-xs font-medium text-stone-400">Categories / <span className="text-stone-700">Electronics</span></div>
        <div className="mt-3 flex items-end justify-between">
          <div><div className="text-2xl font-black tracking-[-.04em]">Explore electronics</div><div className="mt-1 text-xs text-stone-400">{shown.length * 8} items</div></div>
          {filtered && <span className="rounded-full bg-[#fff0ed] px-3 py-1.5 text-[11px] font-bold text-[#e64336]">3 filters</span>}
        </div>
        <div className="my-5 grid grid-cols-2 gap-3">
          <Btn variant="secondary" onClick={() => go("filters")}><Icon name="filter" size={17} /> Filters</Btn>
          <Btn variant="secondary" onClick={() => setSortOpen(true)}><Icon name="sliders" size={17} /> {sort}</Btn>
        </div>
        <div className="grid grid-cols-2 gap-x-4 gap-y-7">
          {shown.map((p) => <ProductCard key={p.id} product={p} onOpen={() => openProduct(p)} wished={wishlist.includes(p.id)} onWish={() => toggleWish(p.id)} />)}
        </div>
      </div>
      {sortOpen && (
        <div className="overlay" onClick={() => setSortOpen(false)}>
          <div className="sheet" onClick={(e) => e.stopPropagation()}>
            <div className="sheet-handle" />
            <div className="mb-5 text-xl font-extrabold">Sort products</div>
            {["Recommended", "Price: Low to High", "Price: High to Low", "Top Rated", "Newest First"].map((x) => (
              <button type="button" key={x} onClick={() => { setSort(x); setSortOpen(false); }} className="flex w-full items-center border-b border-stone-100 py-4 text-sm font-semibold">
                {x}{sort === x && <span className="ml-auto grid h-6 w-6 place-items-center rounded-full bg-[#ff5b4d] text-white"><Icon name="check" size={14} /></span>}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function Filters({ go, apply }: { go: (s: Screen) => void; apply: () => void }) {
  const [brands, setBrands] = useState(["Nova", "Aero"]);
  const [rating, setRating] = useState(4);
  const toggle = (b: string) => setBrands(brands.includes(b) ? brands.filter((x) => x !== b) : [...brands, b]);
  return (
    <div className="flex min-h-[100dvh] flex-col">
      <Header title="Filters & Sort" onBack={() => go("listing")} right={<button type="button" onClick={() => { setBrands([]); setRating(0); }} className="text-xs font-bold text-[#ff5b4d]">Clear all</button>} />
      <div className="flex-1 space-y-7 overflow-auto px-5 py-6 pb-28">
        <FilterBlock title="Price range">
          <div className="mt-4 h-1.5 rounded-full bg-stone-200"><div className="ml-[12%] h-full w-[64%] rounded-full bg-[#ff5b4d]" /></div>
          <div className="mt-4 grid grid-cols-2 gap-3">
            <div className="field"><span>Minimum</span><strong>$25</strong></div><div className="field"><span>Maximum</span><strong>$250</strong></div>
          </div>
        </FilterBlock>
        <FilterBlock title="Brand">
          <div className="flex flex-wrap gap-2">{["Nova", "Aero", "Lumio", "Sona", "Vertex"].map((b) => <Chip key={b} label={b} active={brands.includes(b)} onClick={() => toggle(b)} />)}</div>
        </FilterBlock>
        <FilterBlock title="Minimum rating">
          <div className="flex gap-2">{[3, 4, 4.5].map((r) => <Chip key={r} label={`${r}+ ★`} active={rating === r} onClick={() => setRating(r)} />)}</div>
        </FilterBlock>
        <FilterBlock title="Availability">
          <div className="flex gap-2"><Chip label="In stock" active /><Chip label="Pre-order" /></div>
        </FilterBlock>
        <FilterBlock title="Discount">
          <div className="flex flex-wrap gap-2">{["10%+", "20%+", "30%+", "50%+"].map((x) => <Chip key={x} label={x} />)}</div>
        </FilterBlock>
        <FilterBlock title="Color">
          <div className="flex gap-3">{["bg-stone-900", "bg-white", "bg-[#ff5b4d]", "bg-sky-400", "bg-emerald-500", "bg-amber-300"].map((c, i) => <button type="button" aria-label={`Color ${i + 1}`} key={c} className={`h-9 w-9 rounded-full border-4 border-white shadow-[0_0_0_1px_#ddd] ${c}`} />)}</div>
        </FilterBlock>
        <FilterBlock title="Size">
          <div className="flex gap-2">{["S", "M", "L", "XL"].map((x) => <Chip key={x} label={x} active={x === "M"} />)}</div>
        </FilterBlock>
      </div>
      <div className="fixed bottom-0 left-1/2 z-30 w-full max-w-[430px] -translate-x-1/2 border-t border-stone-200 bg-white/95 p-4 backdrop-blur">
        <Btn onClick={apply} className="w-full">Apply Filters <span className="ml-auto rounded-full bg-white/20 px-2 py-1 text-xs">18 items</span></Btn>
      </div>
    </div>
  );
}

function FilterBlock({ title, children }: { title: string; children: React.ReactNode }) {
  return <div className="border-b border-stone-200 pb-7"><div className="mb-4 text-[15px] font-extrabold">{title}</div>{children}</div>;
}

function Chip({ label, active = false, onClick }: { label: string; active?: boolean; onClick?: () => void }) {
  return <button type="button" onClick={onClick} className={`rounded-full border px-4 py-2.5 text-xs font-bold transition ${active ? "border-[#ff5b4d] bg-[#fff0ed] text-[#e64336]" : "border-stone-200 bg-white text-stone-600"}`}>{label}</button>;
}

function ProductDetails({
  product,
  back,
  wished,
  toggleWish,
  addCart,
  go,
}: {
  product: Product;
  back: () => void;
  wished: boolean;
  toggleWish: () => void;
  addCart: () => void;
  go: (s: Screen) => void;
}) {
  const [color, setColor] = useState(0);
  const [size, setSize] = useState("M");
  const [qty, setQty] = useState(1);
  const [added, setAdded] = useState(false);
  const add = () => { addCart(); setAdded(true); window.setTimeout(() => setAdded(false), 1600); };
  return (
    <div className="pb-28">
      <div className="relative aspect-[1/1.03] overflow-hidden bg-stone-100">
        <img src={product.image} alt={product.name} className="h-full w-full object-cover" />
        <div className="absolute left-4 right-4 top-4 flex justify-between">
          <IconBtn icon="back" label="Go back" onClick={back} className="bg-white/90 shadow-sm backdrop-blur" />
          <IconBtn icon="heart" label="Wishlist" onClick={toggleWish} active={wished} className="bg-white/90 shadow-sm backdrop-blur" />
        </div>
        <div className="absolute bottom-4 left-1/2 flex -translate-x-1/2 gap-1.5 rounded-full bg-white/80 p-2 backdrop-blur">
          <span className="h-1.5 w-5 rounded-full bg-[#171614]" /><span className="h-1.5 w-1.5 rounded-full bg-stone-300" /><span className="h-1.5 w-1.5 rounded-full bg-stone-300" />
        </div>
      </div>
      <div className="px-5 pt-6">
        <div className="mb-2 text-xs font-bold uppercase tracking-[.16em] text-[#ff5b4d]">Best seller</div>
        <div className="text-[28px] font-black leading-tight tracking-[-.045em]">{product.name}</div>
        <div className="mt-2 flex items-center gap-3"><Rating value={product.rating} reviews={product.reviews} /><button type="button" className="text-xs font-semibold text-stone-500 underline">Read reviews</button></div>
        <div className="mt-4"><Price product={product} large /></div>
        <div className="mt-5 border-t border-stone-200 pt-5 text-sm leading-6 text-stone-500">Immersive sound, refined comfort and thoughtful design come together in a premium everyday essential built to move with you.</div>

        <div className="mt-7">
          <div className="mb-3 flex items-center justify-between"><span className="text-sm font-extrabold">Color</span><span className="text-xs text-stone-400">{["Midnight", "Stone", "Coral"][color]}</span></div>
          <div className="flex gap-3">{["bg-[#232323]", "bg-[#d9d4cb]", "bg-[#ff5b4d]"].map((c, i) => <button type="button" aria-label={`Select color ${i + 1}`} onClick={() => setColor(i)} key={c} className={`h-10 w-10 rounded-full border-4 border-white shadow-[0_0_0_${color === i ? "2px_#ff5b4d" : "1px_#ddd"}] ${c}`} />)}</div>
        </div>
        <div className="mt-7">
          <div className="mb-3 flex items-center justify-between"><span className="text-sm font-extrabold">Size</span><button type="button" className="text-xs font-bold text-[#ff5b4d]">Size guide</button></div>
          <div className="flex gap-2">{["S", "M", "L", "XL"].map((x) => <button type="button" key={x} onClick={() => setSize(x)} className={`grid h-11 w-12 place-items-center rounded-xl border text-sm font-bold ${size === x ? "border-[#171614] bg-[#171614] text-white" : "border-stone-200"}`}>{x}</button>)}</div>
        </div>
        <div className="mt-7 flex items-center justify-between border-y border-stone-200 py-5">
          <div><div className="text-sm font-extrabold">Quantity</div><div className="mt-1 text-xs text-emerald-600">In stock, ready to ship</div></div>
          <div className="flex items-center rounded-xl border border-stone-200 p-1"><IconBtn icon="minus" label="Decrease" onClick={() => setQty(Math.max(1, qty - 1))} className="!h-8 !w-8" /><span className="w-8 text-center text-sm font-bold">{qty}</span><IconBtn icon="plus" label="Increase" onClick={() => setQty(qty + 1)} className="!h-8 !w-8" /></div>
        </div>
        <div className="mt-6 rounded-[20px] bg-stone-100 p-4">
          <InfoRow icon="truck" title="Free delivery" subtitle="Arrives Tue, 18 Jun" />
          <InfoRow icon="shield" title="Easy returns" subtitle="30-day return window" />
        </div>
        <SectionInner title="Customer reviews">
          <div className="rounded-[20px] border border-stone-200 bg-white p-4">
            <div className="flex items-center justify-between"><Rating value={5} /><span className="text-xs text-stone-400">2 days ago</span></div>
            <div className="mt-3 text-sm font-bold">Better than I expected</div>
            <div className="mt-1 text-xs leading-5 text-stone-500">Beautifully made, comfortable all day and the sound quality is exceptional.</div>
            <div className="mt-3 text-xs font-semibold text-stone-400">Maya R. · Verified buyer</div>
          </div>
        </SectionInner>
      </div>
      <div className="fixed bottom-0 left-1/2 z-30 flex w-full max-w-[430px] -translate-x-1/2 gap-3 border-t border-stone-200 bg-white/95 p-4 backdrop-blur">
        <Btn variant="secondary" onClick={add} className="flex-1">{added ? <><Icon name="check" size={17} /> Added</> : "Add to Cart"}</Btn>
        <Btn onClick={() => { addCart(); go("cart"); }} className="flex-1">Buy Now</Btn>
      </div>
    </div>
  );
}

function InfoRow({ icon, title, subtitle }: { icon: string; title: string; subtitle: string }) {
  return <div className="flex items-center gap-3 py-2"><span className="grid h-9 w-9 place-items-center rounded-xl bg-white text-[#ff5b4d]"><Icon name={icon} size={18} /></span><span><span className="block text-xs font-bold">{title}</span><span className="mt-0.5 block text-[11px] text-stone-500">{subtitle}</span></span></div>;
}

function Wishlist({ items, openProduct, toggleWish }: { items: Product[]; openProduct: (p: Product) => void; toggleWish: (id: number) => void }) {
  return (
    <div className="pb-28">
      <Header title="Wishlist" eyebrow={`${items.length} saved items`} />
      <div className="px-5 pt-5">
        {items.length ? <div className="grid grid-cols-2 gap-x-4 gap-y-7">{items.map((p) => <ProductCard key={p.id} product={p} onOpen={() => openProduct(p)} wished onWish={() => toggleWish(p.id)} />)}</div> : <Empty icon="heart" title="Your wishlist is waiting" text="Save products you love and find them here anytime." />}
      </div>
    </div>
  );
}

function Cart({
  items,
  quantities,
  changeQty,
  remove,
  go,
}: {
  items: Product[];
  quantities: Record<number, number>;
  changeQty: (id: number, delta: number) => void;
  remove: (id: number) => void;
  go: (s: Screen) => void;
}) {
  const subtotal = items.reduce((sum, p) => sum + p.price * (quantities[p.id] || 1), 0);
  const discount = subtotal > 0 ? 15 : 0;
  return (
    <div className="pb-44">
      <Header title="My Cart" eyebrow={`${items.length} items`} />
      <div className="px-5 pt-5">
        {items.length ? (
          <>
            <div className="space-y-4">
              {items.map((p) => (
                <div key={p.id} className="flex gap-4 rounded-[22px] border border-stone-200 bg-white p-3">
                  <img src={p.image} alt="" className={`h-24 w-24 rounded-2xl object-cover ${p.color}`} />
                  <div className="min-w-0 flex-1 py-1">
                    <div className="truncate text-sm font-bold">{p.name}</div>
                    <div className="mt-1 text-[11px] text-stone-400">Midnight · Medium</div>
                    <div className="mt-2 text-sm font-extrabold">${p.price.toFixed(2)}</div>
                    <div className="mt-2 flex items-center justify-between">
                      <div className="flex items-center rounded-lg bg-stone-100"><IconBtn icon="minus" label="Decrease" onClick={() => changeQty(p.id, -1)} className="!h-7 !w-7" /><span className="w-6 text-center text-xs font-bold">{quantities[p.id] || 1}</span><IconBtn icon="plus" label="Increase" onClick={() => changeQty(p.id, 1)} className="!h-7 !w-7" /></div>
                      <IconBtn icon="trash" label="Remove" onClick={() => remove(p.id)} className="!h-8 !w-8 text-stone-400" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-6 flex gap-2">
              <label className="flex h-12 flex-1 items-center gap-2 rounded-2xl border border-stone-200 bg-white px-4 text-stone-400"><Icon name="coupon" size={18} /><input className="min-w-0 flex-1 bg-transparent text-sm outline-none" placeholder="Promo code" /></label>
              <Btn variant="dark" className="!h-12">Apply</Btn>
            </div>
            <div className="mt-6 rounded-[22px] bg-stone-100 p-5">
              <SummaryRow label="Subtotal" value={`$${subtotal.toFixed(2)}`} />
              <SummaryRow label="Delivery" value="Free" positive />
              <SummaryRow label="Discount" value={`-$${discount.toFixed(2)}`} positive />
              <div className="my-4 border-t border-stone-200" />
              <SummaryRow label="Total" value={`$${(subtotal - discount).toFixed(2)}`} total />
            </div>
          </>
        ) : <Empty icon="bag" title="Your cart is empty" text="Looks like you haven’t added anything yet." action={<Btn onClick={() => go("home")}>Start shopping</Btn>} />}
      </div>
      {items.length > 0 && <div className="fixed bottom-[77px] left-1/2 z-20 w-full max-w-[430px] -translate-x-1/2 border-t border-stone-200 bg-white/95 p-4 backdrop-blur"><Btn onClick={() => go("checkout")} className="w-full">Proceed to Checkout <Icon name="chevron" size={18} /></Btn></div>}
    </div>
  );
}

function SummaryRow({ label, value, positive, total }: { label: string; value: string; positive?: boolean; total?: boolean }) {
  return <div className={`flex items-center justify-between py-1.5 ${total ? "text-lg font-black" : "text-sm"}`}><span className={total ? "" : "text-stone-500"}>{label}</span><span className={`${total ? "" : "font-bold"} ${positive ? "text-emerald-600" : ""}`}>{value}</span></div>;
}

function Empty({ icon, title, text, action }: { icon: string; title: string; text: string; action?: React.ReactNode }) {
  return <div className="flex min-h-[55vh] flex-col items-center justify-center text-center"><span className="grid h-20 w-20 place-items-center rounded-[28px] bg-[#fff0ed] text-[#ff5b4d]"><Icon name={icon} size={34} /></span><div className="mt-5 text-xl font-extrabold">{title}</div><div className="mt-2 max-w-xs text-sm leading-6 text-stone-500">{text}</div>{action && <div className="mt-6">{action}</div>}</div>;
}

function Checkout({ back, placeOrder, total }: { back: () => void; placeOrder: () => void; total: number }) {
  const [step, setStep] = useState(0);
  const [payment, setPayment] = useState("Card ending in 4242");
  const steps = ["Address", "Payment", "Review"];
  return (
    <div className="pb-28">
      <Header title="Checkout" onBack={step === 0 ? back : () => setStep(step - 1)} />
      <div className="px-5 pt-6">
        <div className="mb-8 flex items-start">
          {steps.map((s, i) => <div key={s} className="flex flex-1 flex-col items-center"><div className="flex w-full items-center"><span className={`h-0.5 flex-1 ${i === 0 ? "bg-transparent" : i <= step ? "bg-[#ff5b4d]" : "bg-stone-200"}`} /><span className={`grid h-8 w-8 place-items-center rounded-full text-xs font-bold ${i <= step ? "bg-[#ff5b4d] text-white" : "bg-stone-200 text-stone-400"}`}>{i < step ? <Icon name="check" size={15} /> : i + 1}</span><span className={`h-0.5 flex-1 ${i === 2 ? "bg-transparent" : i < step ? "bg-[#ff5b4d]" : "bg-stone-200"}`} /></div><span className={`mt-2 text-[10px] font-bold ${i === step ? "text-stone-800" : "text-stone-400"}`}>{s}</span></div>)}
        </div>
        {step === 0 && (
          <div>
            <div className="text-xl font-extrabold">Delivery address</div>
            <div className="mt-4 rounded-[22px] border-2 border-[#ff5b4d] bg-[#fff7f5] p-4">
              <div className="flex items-start"><span className="grid h-9 w-9 place-items-center rounded-xl bg-white text-[#ff5b4d]"><Icon name="home" size={18} /></span><div className="ml-3 flex-1"><div className="text-sm font-extrabold">Home</div><div className="mt-1 text-xs leading-5 text-stone-500">Maya Anderson<br />182 Bedford Ave, Brooklyn, NY 11211<br />+1 (212) 555-0189</div></div><span className="grid h-5 w-5 place-items-center rounded-full bg-[#ff5b4d] text-white"><Icon name="check" size={12} /></span></div>
            </div>
            <Btn variant="secondary" className="mt-3 w-full"><Icon name="plus" size={17} /> Add new address</Btn>
            <SectionInner title="Delivery method">
              <div className="flex items-center rounded-[20px] border border-stone-200 bg-white p-4"><Icon name="truck" size={22} /><div className="ml-3 flex-1"><div className="text-sm font-bold">Standard delivery</div><div className="mt-1 text-xs text-stone-400">Tue, 18 Jun · 3–5 business days</div></div><div className="text-sm font-bold text-emerald-600">Free</div></div>
            </SectionInner>
          </div>
        )}
        {step === 1 && (
          <div>
            <div className="text-xl font-extrabold">Payment method</div>
            <div className="mt-4 space-y-3">
              <PaymentOption icon="card" title="Card ending in 4242" subtitle="Expires 08/28" active={payment === "Card ending in 4242"} onClick={() => setPayment("Card ending in 4242")} />
              <PaymentOption icon="cash" title="UPI" subtitle="Pay using any UPI app" active={payment === "UPI"} onClick={() => setPayment("UPI")} />
              <PaymentOption icon="cash" title="Cash on Delivery" subtitle="Pay when your order arrives" active={payment === "Cash on Delivery"} onClick={() => setPayment("Cash on Delivery")} />
            </div>
            <Btn variant="secondary" className="mt-3 w-full"><Icon name="plus" size={17} /> Add payment method</Btn>
            <div className="mt-7 flex gap-3 rounded-[20px] bg-emerald-50 p-4 text-emerald-800"><Icon name="shield" size={22} /><div><div className="text-sm font-bold">Payments are secure</div><div className="mt-1 text-xs leading-5 text-emerald-700">Your payment details are encrypted and never stored.</div></div></div>
          </div>
        )}
        {step === 2 && (
          <div>
            <div className="text-xl font-extrabold">Review your order</div>
            <div className="mt-4 flex gap-3 rounded-[22px] border border-stone-200 bg-white p-3">
              <img src={products[0].image} alt="" className="h-20 w-20 rounded-2xl object-cover" />
              <div className="flex-1 py-1"><div className="text-sm font-bold">{products[0].name}</div><div className="mt-1 text-xs text-stone-400">Midnight · M · Qty 1</div><div className="mt-3 text-sm font-extrabold">${products[0].price}</div></div>
            </div>
            <div className="mt-5 rounded-[22px] bg-stone-100 p-5"><SummaryRow label="Subtotal" value={`$${(total + 15).toFixed(2)}`} /><SummaryRow label="Delivery" value="Free" positive /><SummaryRow label="Discount" value="-$15.00" positive /><div className="my-4 border-t border-stone-200" /><SummaryRow label="Total" value={`$${total.toFixed(2)}`} total /></div>
            <div className="mt-5 rounded-[20px] border border-stone-200 bg-white p-4"><div className="text-xs font-bold text-stone-400">DELIVERING TO</div><div className="mt-2 text-sm font-bold">Maya Anderson · Home</div><div className="mt-1 text-xs text-stone-500">182 Bedford Ave, Brooklyn, NY 11211</div></div>
            <div className="mt-3 rounded-[20px] border border-stone-200 bg-white p-4"><div className="text-xs font-bold text-stone-400">PAYMENT</div><div className="mt-2 flex items-center gap-2 text-sm font-bold"><Icon name="card" size={18} />{payment}</div></div>
          </div>
        )}
      </div>
      <div className="fixed bottom-0 left-1/2 z-30 w-full max-w-[430px] -translate-x-1/2 border-t border-stone-200 bg-white/95 p-4 backdrop-blur"><Btn onClick={() => step < 2 ? setStep(step + 1) : placeOrder()} className="w-full">{step === 2 ? `Place Order · $${total.toFixed(2)}` : "Continue"} <Icon name="chevron" size={18} /></Btn></div>
    </div>
  );
}

function PaymentOption({ icon, title, subtitle, active, onClick }: { icon: string; title: string; subtitle: string; active: boolean; onClick: () => void }) {
  return <button type="button" onClick={onClick} className={`flex w-full items-center rounded-[20px] border-2 p-4 text-left ${active ? "border-[#ff5b4d] bg-[#fff7f5]" : "border-stone-200 bg-white"}`}><span className="grid h-10 w-10 place-items-center rounded-xl bg-white text-stone-700 shadow-sm"><Icon name={icon} size={20} /></span><span className="ml-3 flex-1"><span className="block text-sm font-bold">{title}</span><span className="mt-1 block text-xs text-stone-400">{subtitle}</span></span><span className={`grid h-5 w-5 place-items-center rounded-full border ${active ? "border-[#ff5b4d] bg-[#ff5b4d] text-white" : "border-stone-300"}`}>{active && <Icon name="check" size={12} />}</span></button>;
}

function Confirmation({ go }: { go: (s: Screen) => void }) {
  return (
    <div className="flex min-h-[100dvh] flex-col bg-[#fbfaf7] p-5">
      <div className="flex flex-1 flex-col items-center justify-center text-center">
        <div className="relative grid h-28 w-28 place-items-center rounded-full bg-emerald-100 text-emerald-600">
          <Icon name="check" size={50} />
          <span className="absolute -right-3 top-1 h-4 w-4 rounded-full bg-[#ff5b4d]" /><span className="absolute -left-5 bottom-3 h-3 w-3 rounded-full bg-amber-300" /><span className="absolute -top-4 left-4 h-2.5 w-2.5 rounded-full bg-sky-400" />
        </div>
        <div className="mt-7 text-[30px] font-black leading-tight tracking-[-.045em]">Order placed<br />successfully!</div>
        <div className="mt-3 max-w-xs text-sm leading-6 text-stone-500">Thanks, Maya. Your order is confirmed and we’ll let you know when it ships.</div>
        <div className="mt-7 w-full rounded-[24px] border border-stone-200 bg-white p-5 text-left shadow-sm">
          <div className="flex items-center justify-between border-b border-stone-100 pb-4"><span className="text-xs text-stone-400">ORDER NUMBER</span><span className="text-sm font-extrabold">#SE-24816</span></div>
          <div className="flex items-center gap-3 py-4"><img src={products[0].image} alt="" className="h-16 w-16 rounded-xl object-cover" /><div className="flex-1"><div className="text-sm font-bold">{products[0].name}</div><div className="mt-1 text-xs text-stone-400">Qty 1 · Midnight</div></div><div className="text-sm font-bold">${products[0].price}</div></div>
          <div className="flex items-center gap-3 rounded-2xl bg-stone-100 p-3"><Icon name="truck" size={21} /><div><div className="text-xs font-bold">Estimated delivery</div><div className="mt-0.5 text-xs text-stone-500">Tuesday, 18 June</div></div></div>
        </div>
      </div>
      <div className="space-y-3 pb-3"><Btn onClick={() => go("profile")} className="w-full">Track Order</Btn><Btn onClick={() => go("home")} variant="secondary" className="w-full">Continue Shopping</Btn></div>
    </div>
  );
}

function Profile({ go }: { go: (s: Screen) => void }) {
  const menu = [
    ["box", "My Orders", "3 active"],
    ["heart", "Wishlist", "4 items"],
    ["pin", "Saved Addresses", ""],
    ["card", "Payment Methods", ""],
    ["bell", "Notifications", ""],
    ["help", "Help & Support", ""],
    ["settings", "Settings", ""],
  ];
  return (
    <div className="pb-28">
      <Header title="My Profile" />
      <div className="px-5 pt-6">
        <div className="flex items-center rounded-[26px] bg-[#171614] p-5 text-white">
          <div className="relative"><img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=85" alt="Maya Anderson" className="h-20 w-20 rounded-[24px] object-cover" /><span className="absolute -bottom-1 -right-1 grid h-7 w-7 place-items-center rounded-full border-2 border-[#171614] bg-[#ff5b4d]"><Icon name="camera" size={13} /></span></div>
          <div className="ml-4 min-w-0 flex-1"><div className="text-lg font-extrabold">Maya Anderson</div><div className="mt-1 truncate text-xs text-stone-400">maya.anderson@example.com</div><button type="button" className="mt-3 text-xs font-bold text-[#ff8b80]">Edit profile</button></div>
        </div>
        <div className="mt-6 overflow-hidden rounded-[24px] border border-stone-200 bg-white">
          {menu.map(([icon, label, meta], i) => (
            <button type="button" key={label} onClick={() => label === "Wishlist" ? go("wishlist") : undefined} className={`flex w-full items-center gap-3 p-4 text-left ${i < menu.length - 1 ? "border-b border-stone-100" : ""}`}>
              <span className="grid h-10 w-10 place-items-center rounded-xl bg-stone-100 text-stone-600"><Icon name={icon} size={19} /></span>
              <span className="flex-1 text-sm font-bold">{label}</span>{meta && <span className="text-[11px] font-medium text-stone-400">{meta}</span>}<span className="text-stone-300"><Icon name="chevron" size={17} /></span>
            </button>
          ))}
        </div>
        <button type="button" className="mt-4 flex w-full items-center gap-3 rounded-[18px] bg-red-50 p-4 text-left text-red-600"><Icon name="logout" size={19} /><span className="text-sm font-bold">Log out</span></button>
        <div className="mt-6 text-center text-[11px] text-stone-400">ShopEase v1.0.0 · Made for happier shopping</div>
      </div>
    </div>
  );
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("splash");
  const [history, setHistory] = useState<Screen[]>([]);
  const [selectedProduct, setSelectedProduct] = useState(products[0]);
  const [wishlist, setWishlist] = useState<number[]>([2, 4]);
  const [cart, setCart] = useState<number[]>([1]);
  const [quantities, setQuantities] = useState<Record<number, number>>({ 1: 1 });
  const [filtered, setFiltered] = useState(false);

  useEffect(() => {
    const timer = window.setTimeout(() => setScreen("onboarding"), 1700);
    return () => window.clearTimeout(timer);
  }, []);

  const navigate = (next: Screen) => {
    setHistory((h) => [...h, screen]);
    setScreen(next);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  const direct = (next: Screen) => {
    setScreen(next);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  const back = () => {
    const prev = history[history.length - 1] || "home";
    setHistory((h) => h.slice(0, -1));
    setScreen(prev);
  };
  const openProduct = (p: Product) => { setSelectedProduct(p); navigate("product"); };
  const toggleWish = (id: number) => setWishlist((w) => w.includes(id) ? w.filter((x) => x !== id) : [...w, id]);
  const addCart = (id: number) => {
    setCart((c) => c.includes(id) ? c : [...c, id]);
    setQuantities((q) => ({ ...q, [id]: q[id] || 1 }));
  };
  const cartProducts = products.filter((p) => cart.includes(p.id));
  const subtotal = cartProducts.reduce((sum, p) => sum + p.price * (quantities[p.id] || 1), 0);
  const total = Math.max(0, subtotal - (subtotal ? 15 : 0));
  const changeQty = (id: number, delta: number) => setQuantities((q) => ({ ...q, [id]: Math.max(1, (q[id] || 1) + delta) }));
  const showNav = ["home", "categories", "wishlist", "cart", "profile"].includes(screen);

  const content = useMemo(() => {
    switch (screen) {
      case "splash": return <Splash />;
      case "onboarding": return <Onboarding finish={() => direct("home")} />;
      case "home": return <Home go={navigate} openProduct={openProduct} wishlist={wishlist} toggleWish={toggleWish} />;
      case "categories": return <Categories go={navigate} />;
      case "search": return <SearchScreen go={navigate} openProduct={openProduct} wishlist={wishlist} toggleWish={toggleWish} />;
      case "listing": return <Listing go={navigate} openProduct={openProduct} wishlist={wishlist} toggleWish={toggleWish} filtered={filtered} />;
      case "filters": return <Filters go={navigate} apply={() => { setFiltered(true); direct("listing"); }} />;
      case "product": return <ProductDetails product={selectedProduct} back={back} wished={wishlist.includes(selectedProduct.id)} toggleWish={() => toggleWish(selectedProduct.id)} addCart={() => addCart(selectedProduct.id)} go={navigate} />;
      case "wishlist": return <Wishlist items={products.filter((p) => wishlist.includes(p.id))} openProduct={openProduct} toggleWish={toggleWish} />;
      case "cart": return <Cart items={cartProducts} quantities={quantities} changeQty={changeQty} remove={(id) => setCart((c) => c.filter((x) => x !== id))} go={navigate} />;
      case "checkout": return <Checkout back={back} total={total} placeOrder={() => { setCart([]); direct("confirmation"); }} />;
      case "confirmation": return <Confirmation go={direct} />;
      case "profile": return <Profile go={navigate} />;
    }
  }, [screen, wishlist, cart, quantities, selectedProduct, filtered, subtotal]);

  return (
    <div className="app-shell">
      <main key={screen} className="screen-enter min-h-[100dvh] bg-[#fbfaf7]">{content}</main>
      {showNav && <BottomNav screen={screen} go={direct} cartCount={cart.length} />}
    </div>
  );
}
